# sampleASP.NETapp
Sample ASP.NET Data application using MS SQL server
